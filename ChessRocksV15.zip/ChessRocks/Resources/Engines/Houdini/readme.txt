﻿Houdini 1.5a is a state-of-the-art chess engine for Windows that competes with 
the best commercial and free software.

For all up to date information, download links and contact information, please 
consult the Houdini web site at the following address:

	http://www.cruxis.com/chess/houdini.htm

Houdini is free for non-commercial use. It can be downloaded, installed and 
used for playing chess games and analysis of chess positions. 

Subject to the terms and conditions of this agreement, permission is granted 
to install and execute the software and use the associated files for personal
use. This license does not grant any right of additional use other than the 
above.

This software or the associated files may not be re-distributed in any way 
without prior written permission from the copyright holder.

The software is provided "as is", without express or implied warranty. In no 
event shall the author be liable for any claim, damages or other liability, 
arising from, out of or in connection with the software or the use or other 
dealings in the software.

(c) 2010-11 Robert Houdart, Cruxis