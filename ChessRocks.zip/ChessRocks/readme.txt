
In the zip file I did not provide any pgn or UCI engine files so you need to provide those.
You can look in the ini file to see where I expect to find these files.
I expect this zip file to be unzipped in the c: Drive main directory.
If you do not wish it to be there you need to edit the ini file so it can find the appropriate resource files.

You can make your own pieces by following the example of the provided pieces.
You can also make your own sond files to replace what I have provided.

Any feedback on this program for improvements or bug fixing is welcome.
Email me at kenneth.r.chamberlain@comcast.net
